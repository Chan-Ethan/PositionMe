package com.openpositioning.PositionMe.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.openpositioning.PositionMe.R;

public class ReplayFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private boolean isPlaying = false; // 播放状态
    private int progress = 0; // 进度条进度
    private static final int SEEK_TIME = 10000; // 10秒
    private Handler handler = new Handler();
    private TextView tvProgressTime; // 进度条秒数显示

    public ReplayFragment() {
        // Required empty public constructor
    }

    public static ReplayFragment newInstance(String param1, String param2) {
        ReplayFragment fragment = new ReplayFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 加载 Fragment UI
        return inflater.inflate(R.layout.fragment_replay, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        requireActivity().setTitle("Replay"); // 设置标题

        // 初始化控件
        ImageButton playPauseButton = view.findViewById(R.id.btn_play_pause);
        ImageButton rewindButton = view.findViewById(R.id.btn_rewind);
        ImageButton forwardButton = view.findViewById(R.id.btn_forward);
        Button restartButton = view.findViewById(R.id.btn_restart);
        Button goToEndButton = view.findViewById(R.id.btn_go_to_end);
        Button exitButton = view.findViewById(R.id.btn_exit);
        SeekBar seekBar = view.findViewById(R.id.seek_bar);
        Switch gnssSwitch = view.findViewById(R.id.gnssSwitch);
        tvProgressTime = view.findViewById(R.id.tv_progress_time); // 绑定 TextView

        // 播放/暂停按钮点击事件
        playPauseButton.setOnClickListener(v -> {
            if (isPlaying) {
                pausePlayback();
                playPauseButton.setImageResource(R.drawable.ic_baseline_play_circle_filled_24_b);
            } else {
                startPlayback();
                playPauseButton.setImageResource(R.drawable.ic_baseline_pause_circle_filled_24);
            }
            isPlaying = !isPlaying;
        });

        // 快退 10 秒
        rewindButton.setOnClickListener(v -> {
            int currentPosition = seekBar.getProgress();
            int newPosition = Math.max(currentPosition - SEEK_TIME, 0);
            seekBar.setProgress(newPosition);
            updateTimeDisplay(newPosition);
            Toast.makeText(getContext(), "Rewind 10 seconds", Toast.LENGTH_SHORT).show();
        });

        // 快进 10 秒
        forwardButton.setOnClickListener(v -> {
            int currentPosition = seekBar.getProgress();
            int newPosition = Math.min(currentPosition + SEEK_TIME, seekBar.getMax());
            seekBar.setProgress(newPosition);
            updateTimeDisplay(newPosition);
            Toast.makeText(getContext(), "Forward 10 seconds", Toast.LENGTH_SHORT).show();
        });

        // Restart 按钮点击事件
        restartButton.setOnClickListener(v -> {
            seekBar.setProgress(0);
            updateTimeDisplay(0);
            Toast.makeText(getContext(), "Restart button clicked. Progress reset.", Toast.LENGTH_SHORT).show();
        });

        // Go to End 按钮点击事件
        goToEndButton.setOnClickListener(v -> {
            seekBar.setProgress(seekBar.getMax());
            updateTimeDisplay(seekBar.getMax());
            Toast.makeText(getContext(), "Go to End button clicked. Progress set to max.", Toast.LENGTH_SHORT).show();
        });

        // Exit 按钮点击事件
        exitButton.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Exit button clicked. Exiting...", Toast.LENGTH_SHORT).show();
            requireActivity().onBackPressed();
        });

        // GNSS 开关监听
        gnssSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                Toast.makeText(getContext(), "GNSS Enabled", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "GNSS Disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // 进度条监听器
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateTimeDisplay(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getContext(), "Started dragging SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getContext(), "Stopped dragging SeekBar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startPlayback() {
        Toast.makeText(getContext(), "Playback started", Toast.LENGTH_SHORT).show();
    }

    private void pausePlayback() {
        Toast.makeText(getContext(), "Playback paused", Toast.LENGTH_SHORT).show();
    }

    // 更新时间显示（秒数格式化）
    private void updateTimeDisplay(int progress) {
        int seconds = (progress / 1000) % 60;
        int minutes = (progress / 1000) / 60;
        String time = String.format("%d:%02d", minutes, seconds);
        tvProgressTime.setText(time);
    }


}
